﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {

        }
    }

	public static class DateTimeExtensions
	{
		public static bool IsWorkingDay(this DateTime date)
			=> ((int)date.DayOfWeek).Between(1, 5);

		public static bool Between(this DateTime date, DateTime start, DateTime end)
			=> date >= start && date <= end;
		public static bool Between(this int value, int start, int end)
			=> value >= start && value <= end;
	}
	public class Utility
	{
		public bool IsTaiwanStockWorkingDay(DateTime today)
			=> today.IsWorkingDay() &&
				today.Between(today.Date.AddHours(9), today.Date.AddHours(13.5));

			// DateTime start = new DateTime(today.Year, today.Month, today.Day, 9, 0, 0, 0);
			// DateTime end = new DateTime(today.Year, today.Month, today.Day, 13, 30, 0, 0);
			// DateTime start = today.Date.AddHours(9);
			// DateTime end = today.Date.AddHours(13.5);
			// int weekday = int.Parse(today.DayOfWeek.ToString("d"));
	}
	
}
