﻿namespace ConsoleApp3
{
	internal class Program
	{
		static void Main(string[] args)
		{
			string[] items = { "ZZZ", "AA", "ABD" };
			string value = "ZZZ;AA;ABD";
			string[] items2 = value.Split(';');
		}
	}
}
