﻿namespace ConsoleApp2
{
	internal class Program
	{
		static void Main(string[] args)
		{
			var result1 = new Result // 沒宣告方法時需要先new一個class，再輸入該類別的內容
			{
				IsSuccess = true,
				ErrorMessage = "123"
			};

			var result2 = new Result // 沒宣告方法時需要先new一個class，再輸入該類別的內容
			{
				IsSuccess = false,
				ErrorMessage = "456"
			};

			result1 = Result.Success(); // 有宣告方法時，不需要先new一個class，直接調用方法即可
			result2 = Result.Fail("456");
		}
	}

	public class Result
	{
		public bool IsSuccess { get; set; }
		public bool IsFail => !IsSuccess;

		public string ErrorMessage {  get; set; }

		public static Result Success()
		{
			return new Result { IsSuccess = true };
		}

		public static Result Fail(string errormessage) 
		{
			return new Result { IsSuccess = false, ErrorMessage = errormessage };
		}
	}
}
