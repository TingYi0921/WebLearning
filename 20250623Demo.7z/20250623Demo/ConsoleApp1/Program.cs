﻿using IC.Global.Utilities;
using System.Data.SqlTypes;

namespace ConsoleApp1
{
	internal class Program
	{
		static void Main(string[] args)
		{
			string value = "ABC";
			string result = StringHelper.Truncate(value, 2);
			Console.WriteLine(result);
		}
	}
}
