﻿using System.Runtime.CompilerServices;

namespace IC.Global.Utilities
{
	public class StringHelper
    {
		/// <summary>
		/// 擷取字串左側指定長度
		/// </summary>
		/// <param name="value">原始字串</param>
		/// <param name="length">擷取長度</param>
		/// <returns></returns>
		public static string Truncate(string value, int length)
        {
            if (string.IsNullOrEmpty(value)) return string.Empty;
            if (length <= 0) return string.Empty;

            if (value.Length <= length) return value;

            return value.Substring(0, length);
        }
    }
}
