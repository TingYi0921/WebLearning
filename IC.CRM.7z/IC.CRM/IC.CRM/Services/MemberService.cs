﻿using IC.CRM.DAOs;
using IC.CRM.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace IC.CRM.Services
{
	internal class MemberService
	{
		public void Create(MemberDto dto)
		{
			// todo 驗證欄位有沒有填對
			// todo 判斷商業邏輯, 例如Account 是否唯一

			// 叫用Dao進行存檔
			IMemberDao dao = new MemberDao();
			dao.Create(dto);
		}

		public List<MemberDto> GetAll() { 
			IMemberDao dao = new MemberDao();
			return dao.GetAll();
		}

		public MemberDto Get(int id) 
		{
			IMemberDao dao = new MemberDao();
			return dao.Get(id);
		}

		public void Update(MemberDto dto) 
		{
			// todo 驗證欄位有沒有填對
			// todo 判斷商業邏輯, 例如Account 是否唯一

			// 叫用Dao進行更新
			IMemberDao dao = new MemberDao();
			dao.Update(dto);
		}
	}
}
