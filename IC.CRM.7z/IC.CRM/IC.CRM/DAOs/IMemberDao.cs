﻿using IC.CRM.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IC.CRM.DAOs
{
	internal interface IMemberDao
	{
		void Create(MemberDto dto);

		List<MemberDto> GetAll();

		MemberDto Get(int id);

		void Update(MemberDto dto);
	}
}
