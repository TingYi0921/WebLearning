﻿using IC.CRM.DTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IC.CRM.DAOs
{
	internal class MemberDao : IMemberDao
	{
		public void Create (MemberDto dto)
		{
			// todo 連結到sql server, 並記錄存檔
		}

		public MemberDto Get(int id)
		{
			throw new NotImplementedException();
		}

		public List<MemberDto> GetAll()
		{
			// todo 從 database 取得所有會員紀錄並回傳
			throw new NotImplementedException();
		}

		public void Update(MemberDto dto)
		{
			throw new NotImplementedException();
		}
	}
}
