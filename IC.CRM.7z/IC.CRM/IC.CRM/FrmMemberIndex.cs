﻿using IC.CRM.DTOs;
using IC.CRM.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IC.CRM
{
	public partial class FrmMemberIndex : Form
	{
		public FrmMemberIndex()
		{
			InitializeComponent();
		}

		private void btnSearch_Click(object sender, EventArgs e)
		{
			var service = new MemberService();
			List<MemberDto> members = service.GetAll();
		}
	}
}
