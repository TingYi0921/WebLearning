﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IC.CRM.DTOs
{
	internal class MemberDto
	{
		public string Account { get; set; }
		public string Email { get; set; }
	}
}
