﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManager
{
	abstract class Book
	{
		public string Title { get; set; }
		public string Author { get; set; }
		public bool IsBorrowed { get; private set; }

		public abstract string GetInfo();
		public void Borrow() => IsBorrowed = true;
		public void Return() => IsBorrowed = false;
	}
	class FictionBook : Book
	{
		public string Genre { get; set; }
		public override string GetInfo() => 
			$"{Title} by {Author}(小說 - {Genre} - {(IsBorrowed ? "已借出" : "可借閱")}";
	}
	class ScienceBook : Book
	{
		public string Field {  get; set; }
		public override string GetInfo() =>
			$"{Title} by {Author}(科學 - {Field} - {(IsBorrowed ? "已借出" : "可借閱")}";
	}
}
