﻿namespace LibraryManager
{
	partial class Form1
	{
		/// <summary>
		/// 設計工具所需的變數。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 清除任何使用中的資源。
		/// </summary>
		/// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form 設計工具產生的程式碼

		/// <summary>
		/// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
		/// 這個方法的內容。
		/// </summary>
		private void InitializeComponent()
		{
			this.txtTitle = new System.Windows.Forms.TextBox();
			this.txtAuthor = new System.Windows.Forms.TextBox();
			this.btnInsertNewBook = new System.Windows.Forms.Button();
			this.labelTitle = new System.Windows.Forms.Label();
			this.labelAuthor = new System.Windows.Forms.Label();
			this.CbBoxBookType = new System.Windows.Forms.ComboBox();
			this.lblBookType = new System.Windows.Forms.Label();
			this.lblExtra = new System.Windows.Forms.Label();
			this.txtExtra = new System.Windows.Forms.TextBox();
			this.btnBorrowBook = new System.Windows.Forms.Button();
			this.btnReturnBook = new System.Windows.Forms.Button();
			this.btnShowBooks = new System.Windows.Forms.Button();
			this.listBooks = new System.Windows.Forms.ListBox();
			this.txtBookInfo = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// txtTitle
			// 
			this.txtTitle.Location = new System.Drawing.Point(76, 25);
			this.txtTitle.Name = "txtTitle";
			this.txtTitle.Size = new System.Drawing.Size(249, 22);
			this.txtTitle.TabIndex = 0;
			// 
			// txtAuthor
			// 
			this.txtAuthor.Location = new System.Drawing.Point(76, 70);
			this.txtAuthor.Name = "txtAuthor";
			this.txtAuthor.Size = new System.Drawing.Size(249, 22);
			this.txtAuthor.TabIndex = 1;
			// 
			// btnInsertNewBook
			// 
			this.btnInsertNewBook.Location = new System.Drawing.Point(214, 203);
			this.btnInsertNewBook.Name = "btnInsertNewBook";
			this.btnInsertNewBook.Size = new System.Drawing.Size(111, 28);
			this.btnInsertNewBook.TabIndex = 4;
			this.btnInsertNewBook.Text = "新增書籍";
			this.btnInsertNewBook.UseVisualStyleBackColor = true;
			this.btnInsertNewBook.Click += new System.EventHandler(this.btnInsertNewBook_Click);
			// 
			// labelTitle
			// 
			this.labelTitle.AutoSize = true;
			this.labelTitle.Location = new System.Drawing.Point(5, 28);
			this.labelTitle.Name = "labelTitle";
			this.labelTitle.Size = new System.Drawing.Size(26, 12);
			this.labelTitle.TabIndex = 5;
			this.labelTitle.Text = "Title";
			// 
			// labelAuthor
			// 
			this.labelAuthor.AutoSize = true;
			this.labelAuthor.Location = new System.Drawing.Point(5, 72);
			this.labelAuthor.Name = "labelAuthor";
			this.labelAuthor.Size = new System.Drawing.Size(38, 12);
			this.labelAuthor.TabIndex = 6;
			this.labelAuthor.Text = "Author";
			// 
			// CbBoxBookType
			// 
			this.CbBoxBookType.DisplayMember = "小說";
			this.CbBoxBookType.FormattingEnabled = true;
			this.CbBoxBookType.Items.AddRange(new object[] {
            "小說",
            "科學"});
			this.CbBoxBookType.Location = new System.Drawing.Point(76, 115);
			this.CbBoxBookType.Name = "CbBoxBookType";
			this.CbBoxBookType.Size = new System.Drawing.Size(249, 20);
			this.CbBoxBookType.TabIndex = 7;
			this.CbBoxBookType.SelectedIndexChanged += new System.EventHandler(this.CbBoxBookType_SelectedIndexChanged);
			// 
			// lblBookType
			// 
			this.lblBookType.AutoSize = true;
			this.lblBookType.Location = new System.Drawing.Point(5, 116);
			this.lblBookType.Name = "lblBookType";
			this.lblBookType.Size = new System.Drawing.Size(58, 12);
			this.lblBookType.TabIndex = 8;
			this.lblBookType.Text = "Book Type";
			// 
			// lblExtra
			// 
			this.lblExtra.AutoSize = true;
			this.lblExtra.Location = new System.Drawing.Point(5, 160);
			this.lblExtra.Name = "lblExtra";
			this.lblExtra.Size = new System.Drawing.Size(30, 12);
			this.lblExtra.TabIndex = 9;
			this.lblExtra.Text = "Extra";
			// 
			// txtExtra
			// 
			this.txtExtra.Location = new System.Drawing.Point(76, 158);
			this.txtExtra.Name = "txtExtra";
			this.txtExtra.Size = new System.Drawing.Size(249, 22);
			this.txtExtra.TabIndex = 10;
			this.txtExtra.Visible = false;
			// 
			// btnBorrowBook
			// 
			this.btnBorrowBook.Location = new System.Drawing.Point(576, 25);
			this.btnBorrowBook.Name = "btnBorrowBook";
			this.btnBorrowBook.Size = new System.Drawing.Size(111, 28);
			this.btnBorrowBook.TabIndex = 14;
			this.btnBorrowBook.Text = "借出書籍";
			this.btnBorrowBook.UseVisualStyleBackColor = true;
			this.btnBorrowBook.Click += new System.EventHandler(this.btnBorrowBook_Click);
			// 
			// btnReturnBook
			// 
			this.btnReturnBook.Location = new System.Drawing.Point(690, 25);
			this.btnReturnBook.Name = "btnReturnBook";
			this.btnReturnBook.Size = new System.Drawing.Size(111, 28);
			this.btnReturnBook.TabIndex = 15;
			this.btnReturnBook.Text = "歸還書籍";
			this.btnReturnBook.UseVisualStyleBackColor = true;
			this.btnReturnBook.Click += new System.EventHandler(this.btnReturnBook_Click);
			// 
			// btnShowBooks
			// 
			this.btnShowBooks.Location = new System.Drawing.Point(338, 25);
			this.btnShowBooks.Name = "btnShowBooks";
			this.btnShowBooks.Size = new System.Drawing.Size(111, 28);
			this.btnShowBooks.TabIndex = 16;
			this.btnShowBooks.Text = "顯示所有書籍";
			this.btnShowBooks.UseVisualStyleBackColor = true;
			this.btnShowBooks.Click += new System.EventHandler(this.btnShowBooks_Click);
			// 
			// listBooks
			// 
			this.listBooks.FormattingEnabled = true;
			this.listBooks.ItemHeight = 12;
			this.listBooks.Location = new System.Drawing.Point(338, 59);
			this.listBooks.Name = "listBooks";
			this.listBooks.Size = new System.Drawing.Size(225, 172);
			this.listBooks.TabIndex = 17;
			this.listBooks.SelectedIndexChanged += new System.EventHandler(this.listBooks_SelectedIndexChanged);
			// 
			// txtBookInfo
			// 
			this.txtBookInfo.Location = new System.Drawing.Point(576, 59);
			this.txtBookInfo.Multiline = true;
			this.txtBookInfo.Name = "txtBookInfo";
			this.txtBookInfo.ReadOnly = true;
			this.txtBookInfo.Size = new System.Drawing.Size(225, 172);
			this.txtBookInfo.TabIndex = 18;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(812, 263);
			this.Controls.Add(this.txtBookInfo);
			this.Controls.Add(this.listBooks);
			this.Controls.Add(this.btnShowBooks);
			this.Controls.Add(this.btnReturnBook);
			this.Controls.Add(this.btnBorrowBook);
			this.Controls.Add(this.txtExtra);
			this.Controls.Add(this.lblExtra);
			this.Controls.Add(this.lblBookType);
			this.Controls.Add(this.CbBoxBookType);
			this.Controls.Add(this.labelAuthor);
			this.Controls.Add(this.labelTitle);
			this.Controls.Add(this.btnInsertNewBook);
			this.Controls.Add(this.txtAuthor);
			this.Controls.Add(this.txtTitle);
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox txtTitle;
		private System.Windows.Forms.TextBox txtAuthor;
		private System.Windows.Forms.Button btnInsertNewBook;
		private System.Windows.Forms.Label labelTitle;
		private System.Windows.Forms.Label labelAuthor;
		private System.Windows.Forms.ComboBox CbBoxBookType;
		private System.Windows.Forms.Label lblBookType;
		private System.Windows.Forms.Label lblExtra;
		private System.Windows.Forms.TextBox txtExtra;
		private System.Windows.Forms.Button btnBorrowBook;
		private System.Windows.Forms.Button btnReturnBook;
		private System.Windows.Forms.Button btnShowBooks;
		private System.Windows.Forms.ListBox listBooks;
		private System.Windows.Forms.TextBox txtBookInfo;
	}
}

