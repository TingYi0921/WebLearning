﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManager
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void CbBoxBookType_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (CbBoxBookType.SelectedItem.ToString() == "小說")
			{
				lblExtra.Text = "小說類型";
				txtExtra.Visible = true;
			}
			if (CbBoxBookType.SelectedItem.ToString() == "科學")
			{
				lblExtra.Text = "科學領域";
				txtExtra.Visible = true;
			}
		}

		private void btnInsertNewBook_Click(object sender, EventArgs e)
		{
			Book book;
			string title = txtTitle.Text;
			string author = txtAuthor.Text;
			string extra = txtExtra.Text;

			if (CbBoxBookType.SelectedItem.ToString() == "小說")
			{
				book = new FictionBook { Title = title, Author = author, Genre = extra };
			}
			else
			{
				book = new ScienceBook { Title = title, Author = author, Field = extra };
			}
			List<Book> books = new List<Book>();
			books.Add(book);
			listBooks.Items.Add(book.Title);

			//ClearInputFields();
			txtTitle.Text = "";
			txtAuthor.Text = "";
			CbBoxBookType.SelectedIndex = -1;
			txtExtra.Text = "";
		}

		private void listBooks_SelectedIndexChanged(object sender, EventArgs e)
		{
			List<Book> books = new List<Book>();
			int index = listBooks.SelectedIndex;
			if (index >= 0) 
			{
				Book selectedBook = books[index];
				txtBookInfo.Text = selectedBook.GetInfo();
			}
		}

		private void btnBorrowBook_Click(object sender, EventArgs e)
		{
			List<Book> books = new List<Book>();
			int index = listBooks.SelectedIndex;
			if (index >= 0)
			{
				Book selectedBook = books[index];
				selectedBook.Borrow();
				txtBookInfo.Text = selectedBook.GetInfo();
			}
		}

		private void btnReturnBook_Click(object sender, EventArgs e)
		{
			List<Book> books = new List<Book>();
			int index = listBooks.SelectedIndex;
			if (index >= 0)
			{
				Book selectedBook = books[index];
				selectedBook.Return();
				txtBookInfo.Text = selectedBook.GetInfo();
			}
		}

		private void btnShowBooks_Click(object sender, EventArgs e)
		{
			List<Book> books = new List<Book>();
			txtBookInfo.Clear();
			foreach (Book book in books) 
			{
				txtBookInfo.AppendText(book.GetInfo());
			}
		}
	}
}
