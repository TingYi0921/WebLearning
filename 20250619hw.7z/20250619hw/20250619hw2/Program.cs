﻿namespace _20250619hw2
{
	internal class Program
	{
		static void Main(string[] args)
		{
			var target = new ResizeTarget(800, 600);
			ResizeImage("photo.jpg", target);
			Console.WriteLine($"Image resized to {target.MaxWidth}x{target.MaxHeight}.");
		}
		static void ResizeImage(string fileName, ResizeTarget target)
		{
			int maxWidth = target.MaxWidth;
			int maxHeight = target.MaxHeight;
		}

		class ResizeTarget
		{
			public int MaxWidth { get; set; }
			public int MaxHeight { get; set; }
			public ResizeTarget(int maxWidth, int maxHeight)
			{
				MaxWidth = maxWidth;
				MaxHeight = maxHeight;
			}
		}
	}
}
