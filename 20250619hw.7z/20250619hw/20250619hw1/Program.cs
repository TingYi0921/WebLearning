﻿using System.Runtime.CompilerServices;

namespace _20250619hw1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var allen = new Student("Allen", 90, 85);
			Console.WriteLine($"Name: {allen.Name}, Chinese: {allen.Chinese}, English: {allen.English}");
            Console.WriteLine(allen.Total); // 用屬性Total把分數加起來
			Console.WriteLine(allen.GetTotal()); // 用方法GetTotal把分數加起來
		}
    }

    class Student
    {
		#region properties
		public string Name { get; set; }
		int _chinese;
		public int Chinese 
        {
            get 
            {
                return _chinese;
            }

            set
            {
				_chinese = Score(value);
			}
        }
        int _english;
		public int English
        {
            get
            {
				return _english;
			}
            set
            {
				_english = Score(value);
            }
        }
        public int Total
        {
            get
            {
                return Chinese + English;
            }
        }
		#endregion
		public Student(string name, int chinese, int english)
        {
            Name = name;
            Chinese = chinese;
            English = english;
        }
		#region method
		public static int Score(int a)
        {
            if (a < 0 || a > 100)
            {
                throw new ArgumentOutOfRangeException("分數應該介於 0 到 100之間");
            }
            return a;
        }

        public int GetTotal()
        {
            return _chinese + _english;
        }
		#endregion
	}
}
        
