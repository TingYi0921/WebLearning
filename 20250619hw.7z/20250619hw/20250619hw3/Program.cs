﻿namespace _20250619hw3
{
	internal class Program
	{
		static void Main(string[] args)
		{
			var obj = new NE555(6);
			Console.WriteLine(obj.Ping());
			Console.WriteLine(obj.Ping());
			Console.WriteLine(obj.Ping());
			Console.WriteLine(obj.Ping());
			Console.WriteLine(obj.Ping());
			Console.WriteLine(obj.Ping());
			Console.WriteLine(obj.Ping());
			Console.WriteLine(obj.Ping());
			Console.WriteLine(obj.Ping());
			Console.WriteLine(obj.Ping());
		}
	}
	class NE555
	{
		public int Current { get; set; }
		public int MaxCount { get; set; }
		public NE555(int count)
		{
			Current = 0;
			MaxCount = count;
		}
		public int Ping()
		{
			Current++;
			if (Current > MaxCount)
			{
				Current = 1;
			}
			return Current;
		}
	}
}
