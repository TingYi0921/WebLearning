﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
	public partial class Form1 : Form, IContainer
	{
		public Form1()
		{
			InitializeComponent();
		}

		public void SetValue(string newValue)
		{
			label1.Text = newValue.ToLower();
		}

		private void btnOpenForm2_Click(object sender, EventArgs e)
		{
			var frm = new Form2();
			frm.Show();
		}

		private void btnOpenForm3_Click(object sender, EventArgs e)
		{
			var frm=new Form3();

			frm.Owner = this;
			frm.Show();
		}
	}
}
