﻿using System.Diagnostics.Contracts;

namespace Animals
{
    public class Animal
    {
        public string Name { get; set; }

        public Animal() { }
        public Animal(string name) 
        {
            Name = name;
        }

        public virtual string Sound() => "";

        protected string Eat()=> $"Your pet {Name} eatting meat!";
    }
}
