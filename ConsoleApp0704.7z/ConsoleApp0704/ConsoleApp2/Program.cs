﻿namespace ConsoleApp2
{
	internal class Program
	{
		static void Main(string[] args)
		{
			var name = "Allen Kuo";
			name = "Kuo,Allen";

			UserName result = NameFactory.GetName(name);
			Console.WriteLine($"姓:{result.LastName} 名:{result.FirstName}");
		}
	}

	public static class NameFactory // 建立一個姓名工廠，用來判斷不同的姓名格式
	{
		public static UserName GetName(string fullName)
		{
			return fullName.Contains(",") ? new LastName在前(fullName) : new FirstName在前(fullName); // 判斷名字裡有沒有包含逗號，如果有就new一個LastName在前的物件，沒有則new一個FirstName在前的物件
		}
	}

	public class UserName // 建立一個UserName物件當父類別
	{
		public string FirstName { get; set; }
		public string LastName { get; set; }
	}

	public class FirstName在前 : UserName // 建立一個子類別，繼承UserName這個父類別
	{
		public FirstName在前(string fullName) // 建立該子類別的建構函數(?
		{
			string[] items = fullName.Split(' ');
			FirstName = items[0];
			LastName = items[1];
		}
	}
	public class LastName在前 : UserName
	{
		public LastName在前(string fullName)
		{
			string[] items = fullName.Split(',');
			FirstName = items[1];
			LastName = items[0];
		}
	}
}
