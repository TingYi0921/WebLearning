﻿using WA.ProjectA.Sec;

namespace WA.ProjectA.SQL
{
	public class MemberService : IAuth
	{
		public bool IsValid(string username, string password)
		{
			return (username == "allen"); //供測試用, 若account是allen就回傳正確
		}
	}
}
