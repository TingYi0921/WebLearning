﻿using System.Net;
using System.Reflection;
using WA.ProjectA.Sec;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
			Console.Write("請輸入帳號：");
			string account = Console.ReadLine();
			Console.Write("請輸入密碼：");
			string password = Console.ReadLine();

			Login(account, password);
        }

        static void Login(string account, string password)
        {
            IAuth auth = GetAuthProvider();

            if (auth.IsValid(account, password))
            {
                Console.WriteLine("登入成功");
            }
            else 
            {
                Console.WriteLine("帳號或密碼有誤");
			}
            //throw new Exception("帳號或密碼有誤");
        }

        private static IAuth GetAuthProvider()
        {
            string dllPath = Path.Combine(AppContext.BaseDirectory, "WA.ProjectA.SQL.dll"); // 未來要寫在DB中
			string classname = "WA.ProjectA.SQL.MemberService"; // 未來要寫在DB中

			dllPath = Path.Combine(AppContext.BaseDirectory, "FUEN43.ProjectA.Security.dll");
			classname = "FUEN43.ProjectA.Security.AdvenceMemberService";

			var assembly = Assembly.LoadFrom(dllPath);
            Object obj = assembly.CreateInstance(classname);

            return obj as IAuth;
		}

	}

    //class MemberService_SQL
    //{
    //    public bool IsValid(string account, string password)
    //    {
    //        return true;
    //    }
    //}
}
