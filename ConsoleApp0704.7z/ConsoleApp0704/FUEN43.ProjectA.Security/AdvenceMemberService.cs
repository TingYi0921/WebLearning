﻿using WA.ProjectA.Sec;

namespace FUEN43.ProjectA.Security
{
	public class AdvenceMemberService:IAuth
	{
		public bool IsValid (string username, string password)
		{
			return username == "Simon" && password == "123";
		}
	}
}
