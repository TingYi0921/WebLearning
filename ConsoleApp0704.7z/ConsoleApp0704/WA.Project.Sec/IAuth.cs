﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WA.ProjectA.Sec
{
	public interface IAuth
	{
		bool IsValid(string username, string password);
	}
}
