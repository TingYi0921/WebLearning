﻿using System.Security.Cryptography.X509Certificates;

namespace ConsoleApp5
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Member[] items = {
				new Member{ Name="A", Height=180, DateOfBirth=new DateTime(1970,1,1)},
				new Member{ Name="B", Height=170, DateOfBirth=new DateTime(1960,1,1)},
				new Member{ Name="C", Height=160, DateOfBirth=new DateTime(1980,1,1)}
			};

			IComparer<Member> comparer = Member.按生日遞減; // 有static Property，所以可以直接使用

			Array.Sort(items, comparer); // 放進去排序的實作介面一定要是IComparable

			foreach (var item in items)
			{
				Console.WriteLine(item);
			}
		}
	}

	class Member//:IComparable<Member>
	{
		public static IComparer<Member> 按姓名排序 // 新增一個 static Property，方便外部取用
		{
			get
			{
				return new SortByName();
			}
		}
		public static IComparer<Member> 按姓名遞減 => new SortByNameDESC();
		public static IComparer<Member> 按身高排序 => new SortByHeight();
		public static IComparer<Member> 按身高遞減 => new SortByHeightDESC();
		public static IComparer<Member> 按生日排序 => new SortByDateOfBirth();
		public static IComparer<Member> 按生日遞減 => new SortByDateOfBirthDESC();

		public string Name { get; set; }
		public int Height { get; set; }
		public DateTime DateOfBirth { get; set; }

		//public int CompareTo(Member? other)
		//{
		//	return other.Height.CompareTo(this.Height);
		//	//Member x = this;
		//	//Member y = other;

		//	//if (x.Height > y.Height) return 1; // 前面的比較大就傳回正數
		//	//if (x.Height == y.Height) return 0;
		//	//return -1; // 前面的比較小就傳回負數
		//}

		public override string ToString() // 要從Object類別中覆寫ToString()方法給Member
		{
			return $"姓名:{Name} 身高:{Height} 生日:{DateOfBirth:yyyy/MM/dd}";
		}

		private class SortByName : IComparer<Member>
		{
			public int Compare(Member? x, Member? y)
			{
				return x.Name.CompareTo(y.Name);
			}
		} // 新增巢狀的私有class
		private class SortByNameDESC : IComparer<Member>
		{
			public int Compare(Member? x, Member? y)
			{
				return y.Name.CompareTo(x.Name);
			}
		}
		private class SortByHeight : IComparer<Member>
		{
			public int Compare(Member? x, Member? y)
			{
				return x.Height.CompareTo(y.Height);
			}
		}
		private class SortByHeightDESC : IComparer<Member>
		{
			public int Compare(Member? x, Member? y)
			{
				return y.Height.CompareTo(x.Height);
			}
		}
		private class SortByDateOfBirth : IComparer<Member>
		{
			public int Compare(Member? x, Member? y)
			{
				return x.DateOfBirth.CompareTo(y.DateOfBirth);
			}
		}
		private class SortByDateOfBirthDESC : IComparer<Member>
		{
			public int Compare(Member? x, Member? y)
			{
				return y.DateOfBirth.CompareTo(x.DateOfBirth);
			}
		}
	}
}
