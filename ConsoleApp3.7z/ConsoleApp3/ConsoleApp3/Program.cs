﻿namespace ConsoleApp3
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Teacher allen = new People();
			allen.Name = "allen"; // 此父類別裡沒有Name，因此不能用
			allen.講義 = "xxxxxxxxxx";
		}
	}

	class Teacher
	{
		public string 講義 { get; set; }
	}

	class People : Teacher
	{
		public string Name { get; set; }
	}
}
