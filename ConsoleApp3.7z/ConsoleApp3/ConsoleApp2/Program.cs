﻿namespace ConsoleApp2
{
	internal class Program
	{
		static void Main(string[] args)
		{
			var fs = new FileStorage(@"C:\temp\.txt");
			fs.Save("ABC");

			var ds = new DatabaseStorage();
			ds.Save("ABC");

			//var s = new Storage();
			//s.Save("ABC");
		}
	}
	abstract class Storage
	{
		public abstract void Save(string contect) { }
	}

	class DatabaseStorage : Storage
	{
		public override void Save(string contect) 
		{ 

		}
	}

	class FileStorage : Storage
	{
		private readonly string fullName;

		public FileStorage (string fullName)
		{

		}
	}
}
