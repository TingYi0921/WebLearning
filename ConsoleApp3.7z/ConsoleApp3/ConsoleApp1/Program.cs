﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee[] employees ={
                new Engineer { Name = "Allen", BaseSalary = 40000, Overtime = 5},
                new Sales { Name = "Annie", BaseSalary = 20000, Bonus = 50000 },
                new Manager { Name = "Simon", BaseSalary = 75000 },
                new Engineer { Name = "Eddie", BaseSalary = 50000 }
            };
            foreach (Employee employee in employees)
            {
                int salary = employee.CalculateSalary();
                Console.WriteLine($"{employee.Name} : {salary}");
            }
        }

        public class Employee
        {
            public string Name { get; set; }
            public bool Gender { get; set; }
            public string BadgeNumber { get; set; }
            public int BaseSalary { get; set; }

            public virtual int CalculateSalary()
            {
                return BaseSalary;
            }
        }

        public class Engineer : Employee
        {
            public int Overtime { get; set; }

            public override int CalculateSalary()
            {
                return BaseSalary + Overtime * 500;
            }

			public override string ToString()
			{
				return $"姓名:{Name}, 底薪:{BaseSalary}";
			}
        }
        public class Sales : Employee
        {
            public int Bonus { get; set; }
            public override int CalculateSalary()
            {
                return BaseSalary + Bonus;
            }
        }
        public class Manager : Employee
        {
            // 經理
        }
    }
}
