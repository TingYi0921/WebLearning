﻿namespace ConsoleApp4
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Hello, World!");
		}
	}
	public interface IMember
	{
		// interface 不能宣告 Field
		// interface 不能宣告 建構函數

		// method可以多載
		// 不能寫public or private
		// 不能寫大括號，只能接分號，類似抽象方法的宣告方式

		int Add(int n1, int n2);
		int Add(int n1);

		// Property
		// 不能寫public pr private
		// 只能寫 get;set;不能實際為他們寫程式
		int Height {  get; set; }
	}
}
