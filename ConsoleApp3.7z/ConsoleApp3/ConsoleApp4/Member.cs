﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
	internal class Member:IMember
	{
		//public string Name; // Field
		//public Member() { } // Constructor

		// method, 可多載
		public int Add(int n1, int n2)
		{
			return n1 + n2;
		}

		public int Add(int n1)
		{
			return n1;
		}

		private int _height;
		public int Height
		{
			get { return _height; }
			set { _height = value; }
		}

		//public int Weight { get; set; }
	}
}
