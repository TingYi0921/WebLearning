﻿namespace ConsoleApp5
{
	internal class Program
	{
		static void Main(string[] args)
		{
			#region 取得日期不同的寫法

			DateTime dt1 = DateTime.Now;
			DateTime dt2 = DateTime.Today;
			DateTime dt3 = new DateTime(2020, 6, 15);
			dt3 = new DateTime(2021, 6, 15, 20, 18, 55);
			dt3 = new DateTime(2021, 6, 15, 20, 18, 55, 991);

			DateTime dt4 = DateTime.Parse("2022/06/25");
			DateTime dt5 = DateTime.Parse("2022/06/25 17:05:16");
			#endregion
			#region 取得常用的屬性值
			dt1 = new DateTime(2025, 6, 2, 13, 0, 0);
			int year = dt1.Year; // 2025
			int month = dt1.Month; // 6
			int day = dt1.Day; // 2

			int hour = dt1.Hour; // 13
			int minute = dt1.Minute; // 0
			int second = dt1.Second; // 0
			int microsecond = dt1.Microsecond;

			bool IsLeapYear = DateTime.IsLeapYear(year); // 某年是不是閏年
			int days = DateTime.DaysInMonth(year, month); // 某年某月有幾天，通常用來算二月有幾天

			dt1 = DateTime.Now; // 包括日期與時間
			dt2 = dt1.Date; // 只有日期，時間式0:00:00，去除時間的意思
			#endregion
			#region 常用方法
			dt1 = DateTime.Now;
			dt2 = dt1.AddDays(1); // 明天的這個時候
			dt3 = dt1.AddMonths(1);
			dt4 = dt1.AddYears(1);
			dt5 = dt1.AddDays(-1); // 昨天的這個時候

			dt2 = new DateTime(dt1.Year, dt1.Month+1, dt1.Day); // 不可以直接加，否則當年有2/29，下一年也會有2/29，月則會出現第13月，天則會出現第32天
			#endregion

			// 日期只能相減，無法做 +, *, /
			dt1 = new DateTime(2025, 6, 20, 8, 0, 0);
			dt2 = new DateTime(2025, 6, 21, 10, 0, 0);
			TimeSpan ts = dt2 - dt1;

			Console.WriteLine(ts.Days);
			Console.WriteLine(ts.TotalDays);
			Console.WriteLine(ts.Hours);
			Console.WriteLine(ts.TotalHours);
		}
	}
}
