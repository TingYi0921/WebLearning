﻿using System.Data.Common;

namespace ConsoleApp3
{
	internal class Program
	{
		static void Main(string[] args)
		{
			try
			{
				DoB();
			}
			catch (Exception ex)
			{
				throw new Exception("系統暫時停止服務，請稍後再試!");
			}
		}

	static void DoB()
		{
			int value = -5;
			try
			{
				DoA(value);
			} 
			catch (Exception ex) 
			{
				throw new Exception("抱歉，出現錯誤", ex);
			}
		}
	static void DoA(int num)
		{
			if (num < 0)
			{
				throw new Exception("num不能為負數");
			}
		}
	}
}
