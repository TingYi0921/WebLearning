﻿using System.Diagnostics.CodeAnalysis;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int sum = Add(31,55);
				Console.WriteLine(sum);
            }
            catch (Exception ex)
            {
                Console.WriteLine("系統暫時停止服務，請稍後再試");
            }
            Console.WriteLine("成功");
        }
        static int Add(int n1, int n2)
        {
            if (n1 % 2 == 0)
            {
                throw new Exception("相加時，第一個數字不能是偶數");
            }
            int sum = n1 + n2;
            if (sum > 100)
            {
                throw new Exception("相加後的值不能超過100");
            }
            return sum;
        }
    }
}
