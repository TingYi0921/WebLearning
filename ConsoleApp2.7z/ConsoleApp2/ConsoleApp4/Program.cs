﻿namespace ConsoleApp4
{
	internal class Program
	{
		static void Main(string[] args)
		{
			int result = Calculate(OptionType.加, 85, 10);

			string fullname = @"C:\temp\image.jpg";
			CopyFile(fullname, @"D:\temp\image.jpg", FileOption.覆蓋);
		}
		static int Calculate(OptionType option, int n1, int n2) 
		{
			switch(option) {
				case OptionType.加 :
					return n1 + n2;
				case OptionType.減 :
					return n1 - n2;
				case OptionType.乘 :
					return n1 * n2;
				case OptionType.除 :
					return n1 / n2;
				default:
					throw new Exception("看不懂此運算式");
		}

		static void CopyFile(string fullname, string filepath, FileOption option) 
		{
			
		}

	enum OptionType
	{
		加,
		減,
		乘,
		除
	}

	enum FileOption
	{
		覆蓋,
		不做動作,
		串接在最後方
	}
}
