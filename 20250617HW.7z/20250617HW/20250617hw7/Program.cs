﻿namespace _20250617hw7
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Console.Write("請輸入身高: ");
			string heightInput = Console.ReadLine();

			bool isHeight = int.TryParse(heightInput, out int height);
			if (!isHeight)
			{
				Console.WriteLine("身高輸入錯誤，請輸入有效的數字。");
				return;
			}

			Console.Write("請輸入體重: ");
			string weightInput = Console.ReadLine();

			bool isWeight = int.TryParse(weightInput, out int weight);
			if (!isWeight)
			{
				Console.WriteLine("體重輸入錯誤，請輸入有效的數字。");
				return;
			}

			if (height <= 0 || weight <= 0)
			{
				Console.WriteLine("身高和體重必須是正數。");
				return;
			}

			double heightInMeters = height / 100.0; // 將身高轉換為米

			double bmi = weight / (heightInMeters * heightInMeters); // 計算BMI

			string bmiCategory;

			if (bmi < 18.5)
			{
				bmiCategory = "體重過輕:BMI<=18.5";
			}
			else if (bmi < 24.0)
			{
				bmiCategory = "正常範圍:18.5<=BMI<24.0";
			}
			else if (bmi < 27.0)
			{
				bmiCategory = "過重:24<=BMI<27";
			}
			else if (bmi < 30.0)
			{
				bmiCategory = "輕度肥胖:27 <= BMI < 30";
			}
			else if (bmi < 35.0)
			{
				bmiCategory = "中度肥胖:30 <= BMI < 35";
			}
			else
			{
				bmiCategory = "重度肥胖:BMI >= 35";
			}
			Console.WriteLine(bmiCategory);
		}
	}
}
