﻿namespace _20250617hw12
{
	internal class Program
	{
		/// <summary>
		/// 想用一百元買剛好一百隻雞(每種雞都至少要一隻), 公雞每隻 5 元, 母雞每隻 3 元, 小雞三隻 1 元
		/// 請顯示購買的組合方式, 三種雞各買幾隻, 一共跑了多少次迴圈
		/// </summary>
		/// <param name="args"></param>
		static void Main(string[] args)
		{
			int Cock = 5;
			int hen = 3;
			int Chicken = 1;
			int total = 100;
			int loopCount = 0; // 計算迴圈次數

			for (int i = 0; i <= total / Cock; i++) // 公雞數量
			{
				for (int j = 0; j <= total / hen; j++) // 母雞數量
				{
					int k = total - i - j; // 小雞數量
					if (k % 3 == 0 && k >= 0) // 小雞必須是三的倍數且不能為負
					{
						int ChickenCount = k / 3;
						if (i * Cock + j * hen + ChickenCount * Chicken == total)
						{
							Console.WriteLine($"公雞: {i}, 母雞: {j}, 小雞: {ChickenCount}");
						}
						loopCount++; // 每次迴圈都計算一次
					}
				}
			}
			Console.WriteLine($"總迴圈次數: {loopCount}");
		}
	}
}
