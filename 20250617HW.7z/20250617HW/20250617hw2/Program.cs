﻿namespace _20250617hw2
{
	internal class Program
	{
		static void Main(string[] args)
		{
			decimal a = 10, b = 3;
			Console.WriteLine($"加法: {Calculator.Add(a, b)}");
			Console.WriteLine($"減法: {Calculator.Subtract(a, b)}");
			Console.WriteLine($"乘法: {Calculator.Multiply(a, b)}");
			Console.WriteLine($"除法: {Calculator.Divide(a, b)}");
		}
	}

	class Calculator
	{
		private decimal _result;
		public static decimal Add(decimal a, decimal b)
		{
			return a + b;
		}
		public static decimal Subtract(decimal a, decimal b)
		{
			return a - b;
		}
		public static decimal Multiply(decimal a, decimal b)
		{
			return a * b;
		}
		public static decimal Divide(decimal a, decimal b)
		{
			if (b == 0)
			{
				throw new DivideByZeroException("除數不能為零。");
			}
			decimal _result = Math.Round(a / b, 2);

			return _result;
		}
	}
}
