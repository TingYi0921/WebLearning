﻿namespace _20250617hw13
{
	internal class Program
	{
		static void Main(string[] args)
		{
			int[] dices = DiceGame.Roll();
			for (int i = 0; i < dices.Length; i++)
			{
				Console.WriteLine(dices[i]);
			}
		}
	}
	public class DiceGame
	{
		public static int[] Roll()
		{
			int[] diceNum = new int[4];
			Random rand = new Random();
			for (int i = 0; i < diceNum.Length; i++)
			{
				diceNum[i] = rand.Next(1, 7);
			};
			return diceNum;
		}
	}
}
