﻿namespace _20250617hw14
{
	internal class Program
	{
		static void Main(string[] args)
		{
			int result = 0;

			int i = 1;

			while(result < 250)
			{
				result += i;
				i += 2;
			}
			Console.WriteLine($"last number: {i} sum: {result}");
		}
	}
}
