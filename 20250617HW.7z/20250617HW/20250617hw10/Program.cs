﻿namespace _20250617hw10
{
	internal class Program
	{
		static void Main(string[] args)
		{
			void ResizeImage(string fileName, int maxwidth, int maxheight, string targetPath)
			{

			}
		}
	}
}
