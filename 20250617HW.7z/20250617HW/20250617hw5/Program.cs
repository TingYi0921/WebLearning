﻿namespace _20250617hw5
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Car car = new Car("Ford", "Focus", 120);
			Console.WriteLine(car.Accelerate(100));
			Console.WriteLine(car.Brake(20));
			Console.WriteLine(car.DisplayInfo());
		}
	}
	class Car
	{
		public string Brand;
		public string Model;
		public int Speed;
		public Car(string brand, string model, int speed)
		{
			Brand = brand;
			Model = model;
			Speed = speed;
		}
		public string Accelerate(int amount)
		{
			Speed += amount;
			return $"{Brand} {Model} 的速度增加了 {amount} 公里/小時，現在速度為 {Speed} 公里/小時。";
		}
		public string Brake(int amount)
		{
			if (Speed - amount < 0)
			{
				Speed = 0;
			}
			else
			{
				Speed -= amount;
			}
			return $"{Brand} {Model} 的速度減少了 {amount} 公里/小時，現在速度為 {Speed} 公里/小時。";
		}
		public string DisplayInfo()
		{
			return $"品牌: {Brand}, 型號: {Model}, 當前速度: {Speed} 公里/小時";
		}
	}
}
