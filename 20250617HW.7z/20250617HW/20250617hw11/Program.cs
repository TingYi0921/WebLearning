﻿namespace _20250617hw11
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine(生成九九乘法表(2, 9));
		}

		static string 生成一項(int a, int b)
		{
			return $"{a} * {b} = {a * b}";
		}

		static string 生成一列(int n)
		{
			string result = "";
			for (int i = 1; i <= 9; i++)
			{
				result = result + " " + 生成一項(n, i);
			}
			result += "\n";
			return result;
		}
		static string 生成九九乘法表(int begin, int end)
		{
			string result = "";
			for (int i = begin; i <= end; i++)
			{
				result += 生成一列(i);
			}
			return result;
		}
	}
}
