﻿namespace _20250617hw8
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Console.Write("請輸入字串: ");
			string input = Console.ReadLine();

			bool isValid = double.TryParse(input, out double number);
			if (!isValid)
			{
				Console.WriteLine("輸入錯誤，請輸入有效的數字。");
			}
			else
			{
				Console.WriteLine($"輸入的數字是: {number * 2}");
			}
		}
	}
}