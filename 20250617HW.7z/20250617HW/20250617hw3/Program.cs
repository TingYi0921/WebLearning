﻿namespace _20250617hw3
{
	internal class Program
	{
		static void Main(string[] args)
		{
			BankAccount ian = new BankAccount("Ian", 950000);
			Console.WriteLine(ian.DisplayBalance());
			Console.WriteLine(BankAccount.Deposit(ian, 50000));
			Console.WriteLine(BankAccount.Withdraw(ian, 999999));
		}
	}

	class BankAccount
	{
		public string AccountHolder;
		public decimal Balance;

		public BankAccount(string accountHolder, decimal initialBalance)
		{
			AccountHolder = accountHolder;
			Balance = initialBalance;
		}

		public static string Deposit(BankAccount account, decimal amount)
		{
			if (amount <= 0)
			{
				return "存款金額必須大於零。";
			}
			account.Balance += amount;
			return $"存款成功! 新餘額: {account.Balance}";
		}

		public static string Withdraw(BankAccount account, decimal amount)
		{
			if (amount <= 0)
			{
				return "提款金額必須大於零。";
			}
			if (amount > account.Balance)
			{
				return "餘額不足，無法提款。";
			}
			account.Balance -= amount;
			return $"提款成功! 新餘額: {account.Balance}";
		}

		public string DisplayBalance()
		{
			return $"帳戶持有人: {AccountHolder}, 餘額: {Balance}";
		}
	}
}
