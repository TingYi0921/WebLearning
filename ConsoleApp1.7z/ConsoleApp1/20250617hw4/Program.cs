﻿namespace _20250617hw4
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Product name = new Product("iPhone", 29900);
			Console.WriteLine(name.ApplyDiscount(10));
		}
	}
	class Product
	{
		public string Name;
		public double Price;
		public Product(string name, double price)
		{
			Name = name;
			Price = price;
		}
		public string ApplyDiscount(double percentage)
		{
			if (percentage < 0 || percentage > 100)
			{
				return "折扣百分比必須在0到100之間。";
			}
			double discountAmount = Price * (percentage / 100);
			double discountedPrice = Price - discountAmount;
			return $"產品名稱: {Name}, 原價: {Price}, 折扣後價格: {discountedPrice}";
		}
	}
}
