﻿using System.ComponentModel;

namespace ConsoleApp19List
{
	internal class Program
	{
		static void Main(string[] args)
		{
			List<string> students = new List<string> { "Ian", "Allen", "Anbert", "Cathy" };
			students.Add("David");
			students.Add("Ema");

			List<int> scores = new List<int> { 100, 90, 80, 70 };
			scores.Add(80);
			scores.Add(85);

			foreach (string student in students)
			{
				Console.WriteLine(student);
			}

			for (int i = 0; i < students.Count; i++)
			{
				if (i >= students.Count || i >= scores.Count)
				{
					Console.WriteLine("超出索引值範圍");
				}
				Console.WriteLine($"學生: {students[i]}, 分數: {scores[i]}");
			}
		}
	}
}
