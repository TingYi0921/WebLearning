﻿namespace hw1
{
	internal class Program
	{
		static void Main(string[] args)
		{
			int rows4 = 5;
			for (int i = rows4; i >= 1; i--)
			{
				string row4 = new string('*', i);
				Console.WriteLine(row4);
			}
			Console.WriteLine("-------------");

			int rows5 = 5;
			for (int i = rows5; i >= 1; i--)
			{
				string row5 = new string('*', i).PadLeft(rows5, ' ');
				Console.WriteLine(row5);
			}
			Console.WriteLine("-------------");

			int rows6 = 5;
			for (int i = rows6; i >= 1; i--)
			{
				string row6 = new string(' ', rows6 - i) + new string('*', 2 * i - 1);
				Console.WriteLine(row6);
			}
		}
	}
}
