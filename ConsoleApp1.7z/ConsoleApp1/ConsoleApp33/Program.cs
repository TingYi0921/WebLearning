﻿namespace ConsoleApp33
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Member ian = new Member();
			ian.Name = "Ian";
			ian.Email = "ian@gmail.com";

			string message = $"{ian.Name}的Email: {ian.Email}";
			Console.WriteLine(message);

			Member john = new Member();
			john.Name = "John";
			john.Email = "john@gmail.com";

			message = $"{john.Name}的Email: {john.Email}";
			Console.WriteLine(message);

			Member mary = new Member();
			mary.Name = "Mary";
			mary.Email = "mary@gmail.com";

			Console.WriteLine(mary.GetInfo());
		}
	}

	class Member
	{
		public string Name;
		public string Email;

		public string GetInfo() //方法，Method
		{
		string message = $"{Name}的Email: {Email}";
		return message;
		}
	}
}
