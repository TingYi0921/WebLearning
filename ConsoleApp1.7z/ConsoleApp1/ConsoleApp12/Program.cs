﻿using System.Threading.Channels;

namespace ConsoleApp12
{
	internal class Program
	{
		static void Main(string[] args)
		{
			//bool gender = true;

			//int height = 201; // 預設身高

			//int weight = 83; // 預設體重

			Console.Write("請輸入性別 (M/F): ");
			string gender = Console.ReadLine().Trim().ToUpper(); // 去除空白並轉為大寫

			bool isMale;

			if (gender == "M")
			{
				isMale = true;
			}
			else if (gender == "F")
			{
				isMale = false;
			}
			else
			{
				Console.WriteLine("輸入錯誤，請輸入 'M' 或 'F'");
				return;
			}

			Console.Write("請輸入身高: ");
			int height = int.Parse(Console.ReadLine());

			Console.Write("請輸入體重: ");
			int weight = int.Parse(Console.ReadLine());

			if (isMale == false && height > 170)
			{
				Console.WriteLine("妳好高啊!");
			}
			else if(height > 190 && weight > 80)
			{
				Console.WriteLine("你很高也很壯!");
			}
			else if(height < 130 || height > 200)
			{
				Console.WriteLine("您好，歡迎來參加活動!");
			}
			else
			{
				Console.WriteLine("您好，很高興認識你!");
			}
		}
	}
}
