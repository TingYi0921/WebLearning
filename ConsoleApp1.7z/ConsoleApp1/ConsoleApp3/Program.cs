﻿namespace ConsoleApp3
{
	internal class Program
	{
		static void Main(string[] args)
		{
			int total = 1;
			Console.WriteLine(total);

			//total = total + 2;
			//Console.WriteLine(total);

			total += 2;
			Console.WriteLine(total);

			total = 999;
			Console.WriteLine(total);

			const Double taxRate = 0.05;

			Double priceWithTax = 100 + 100 * taxRate;
			Console.WriteLine(priceWithTax);
		}
	}
}
