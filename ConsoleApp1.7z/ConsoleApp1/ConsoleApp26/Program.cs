﻿namespace ConsoleApp26
{
	internal class Program
	{
		static void Main(string[] args)
		{
			int num = 100;

			for (int i = 0; i <= num; i++)
			{
				if (i % 7 == 0 && i >= 13)
				{
					Console.WriteLine(i);
				}
			}
		}
	}
}
