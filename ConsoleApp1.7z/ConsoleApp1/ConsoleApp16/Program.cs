﻿namespace ConsoleApp16
{
	internal class Program
	{
		static void Main(string[] args)
		{
			int a = 15; // 假設 a 為 15
			int b = 20; // 假設 b 為 10
			int c = 6; // 假設 c 為 25
			int max = 0; // 定義一個整數變數 max 用來存儲最大值

			max = (a > b) ? ((a > c) ? a : c) : ((b > c) ? b : c); // 使用巢狀三元運算子找出最大值

			Console.WriteLine($"最大值為: {max}");
		}
	}
}
