﻿namespace _20250617hw6
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Book book = new Book("C# Programming", "John Doe", false);
			Console.WriteLine(book.Borrow());
			Console.WriteLine(book.Return());
			Console.WriteLine(book.DisplayInfo());
		}
	}
	class Book
	{
		public string Title;
		public string Author;
		public bool IsBorrowed;
		public Book(string title, string author, bool isBorrowed)
		{
			Title = title;
			Author = author;
			IsBorrowed = isBorrowed;
		}
		public string Borrow()
		{
			if (IsBorrowed)
			{
				return "這本書已借出。";
			}
			IsBorrowed = true;
			return $"成功借出書籍: {Title}";
		}
		public string Return()
		{
			if (!IsBorrowed)
			{
				return "這本書已歸還。";
			}
			IsBorrowed = false;
			return $"成功歸還書籍: {Title}";
		}
		public string DisplayInfo()
		{
			return $"書名: {Title}, 作者: {Author}, 是否已借出: {IsBorrowed}";
		}
	}
}
