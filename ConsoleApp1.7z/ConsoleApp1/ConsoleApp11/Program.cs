﻿namespace ConsoleApp11
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Console.Write("請輸入8~16個字的密碼: ");
			string password = Console.ReadLine();

			if (password.Length >= 17)
			{
				Console.WriteLine("密碼長度太長，請重新輸入");
			}
			else if (password.Length == 0)
			{
				Console.WriteLine("密碼不能為空，請重新輸入");
			}
			else if (password.Length < 8 && password.Length > 0)
			{
				Console.WriteLine($"密碼長度不足，請重新輸入，當前長度為 {password.Length} 字元");
			}
			else
			{
				Console.WriteLine("密碼輸入成功");
			}
		}
	}
}
