﻿namespace ConsoleApp8
{
	internal class Program
	{
		static void Main(string[] args)
		{
			var value = string.Empty;
			var result = Truncate(value, 1);
			Console.WriteLine(result);
		}
		static string Truncate(string value, int lenght)
		{
			return value.Substring(0, lenght);
		}
	}
}
