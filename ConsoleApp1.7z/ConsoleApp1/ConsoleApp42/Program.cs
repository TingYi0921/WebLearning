﻿namespace ConsoleApp42
{
	internal class Program
	{
		static void Main(string[] args)
		{
			int sum1 = Add(1, 2, 8, 5);
			Console.WriteLine(sum1);
		}

		static int Add(int a, int b)
		{
			return a + b;
		}

		static int Add(int a, int b, params int[] other)
		{
			int sum = a + b;
			foreach (int i in other)
			{
				sum += i;
			}
			return sum;
		}
	}
}
