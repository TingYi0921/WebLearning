﻿namespace ConsoleApp30
{
	internal class Program
	{
		static void Main(string[] args)
		{
			double n = 0.05665;
			string n1 = n.ToString("p"); // "p" is the standard format specifier for percentage
			string n2 = n.ToString("p1");
			string n3 = n.ToString("p0");
			Console.WriteLine(n1);
			Console.WriteLine(n2);
			Console.WriteLine(n3);
		}
	}
}
