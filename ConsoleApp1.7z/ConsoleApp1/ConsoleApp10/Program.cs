﻿namespace ConsoleApp10
{
	internal class Program
	{
		static void Main(string[] args)
		{
			string name = "Ian";

			int length = name.Length;
			Console.WriteLine($"您的名字 {name} 的字串長度是 {length}");
		}
	}
}
