﻿namespace ConsoleApp25
{
	internal class Program
	{
		static void Main(string[] args)
		{
			int num = 91;
			while (num % 7 != 0)
			{
				num++;
			}
			Console.WriteLine(num);
		}
	}
}
