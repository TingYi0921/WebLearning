﻿namespace ConsoleApp29
{
	internal class Program
	{
		static void Main(string[] args)
		{
			int price = 210;

			int tax = (int)Math.Round(price * 0.05, MidpointRounding.AwayFromZero);

			Console.WriteLine(tax);
		}
	}
}
