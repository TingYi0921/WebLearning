﻿namespace ConsoleApp18
{
	internal class Program
	{
		static void Main(string[] args)
		{
			string[] students = {"Ian", "Allen", "Anbert", "Cathy"};
			int[] scores = { 100, 90, 80, 70};

			for (int i = 0; i < students.Length; i++)
			{
				students[i] = students[i].ToUpper();
				Console.WriteLine(students[i]);
			}

			foreach (string student in students)
			{
				Console.WriteLine(student);
			}
		}
	}
}
