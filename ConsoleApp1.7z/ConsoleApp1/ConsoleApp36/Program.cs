﻿namespace ConsoleApp36
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine($"Area: {Rectangle.GetArea(20, 50)}");
			Console.WriteLine($"Perimeter: {Rectangle.GetPerimeter(20, 50)}");
		}
	}

	class Rectangle
	{
		public static decimal GetArea(decimal length, decimal width)
		{
			return length * width;
		}

		public static decimal GetPerimeter(decimal length, decimal width)
		{
			return 2 * (length + width);
		}
	}
}
