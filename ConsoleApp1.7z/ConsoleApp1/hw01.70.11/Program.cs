﻿namespace hw01._70._11
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Rows(7);
		}

		static int Rows(int a) 
		{
			for (int i = 0; i < a; i++)
			{
				string row = new string(' ', i) + "#";
				Console.WriteLine(row);
			}
			for (int i = a - 1; i > 0; i--)
			{
				string row = new string(' ', i - 1) + "#";
				Console.WriteLine(row);
			}
			return a;
		}
	}
}
