﻿namespace ConsoleApp7
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Console.Write("請輸入姓: ");

			string lastName = Console.ReadLine();

			Console.Write("請輸入名: ");

			string firstName = Console.ReadLine();

			Console.Write("請輸入Email: ");

			string email = Console.ReadLine();

			string message = $"您好, {lastName} {firstName}\r\n您的電子信箱是: {email}";

			Console.WriteLine(message);

			//Console.WriteLine("您好, " + lastName + " " + firstName + "\n" + "您的電子信箱是: " + email);
		}
	}
}
