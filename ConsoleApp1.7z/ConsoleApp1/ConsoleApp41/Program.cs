﻿namespace ConsoleApp41
{
	internal class Program
	{
		static void Main(string[] args)
		{
			var ian = new Student("Ian", 90);
			Console.WriteLine(ian.Score);
		}
	}

	class Student
	{
		public string Name { get; set; } // Property with a getter and setter
		public int Score { get; set; } // Property with a getter and setter

		public Student(string name)
		{
			Name = name;
		}

		public Student(string name, int score): this(name) // Constructor chaining,this calls the first constructor
		{
			//Name = name;
			Score = score;
		}
	}
}
