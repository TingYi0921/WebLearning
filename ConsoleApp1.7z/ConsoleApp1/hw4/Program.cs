﻿namespace hw4
{
	internal class Program
	{
		static void Main(string[] args)
		{
			int rows = 5;
			for (int i = 1; i <= rows; i++)
			{
				//string row = new string('+', rows - i) + new string(i.ToString()[0], i);
				string row = new string(i.ToString()[0], i).PadLeft(rows, '+');
				Console.WriteLine(row);
			}
		}
	}
}
