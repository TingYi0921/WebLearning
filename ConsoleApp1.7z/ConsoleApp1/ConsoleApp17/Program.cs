﻿namespace ConsoleApp17
{
	internal class Program
	{
		static void Main(string[] args)
		{
			//for (int i = 0; i < 1001; i += 50)
			//{
			//	Console.WriteLine(i);
			//}

			for (int i = 0; i < 10; i++)
			{
				if(i >= 7)
				{
					break;
				}
				if(i <= 3)
				{
					continue; // 跳過 i < 3 的情況
				}
				Console.WriteLine(i);
			}
		}
	}
}
