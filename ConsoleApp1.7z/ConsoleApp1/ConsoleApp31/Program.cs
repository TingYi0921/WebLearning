﻿namespace ConsoleApp31
{
	internal class Program
	{
		static void Main(string[] args)
		{
			string name = "Ian";
			int age = 27;

			string message1 = $"My name is {name} and I am {age} years old.";
			Console.WriteLine(message1);

			string message2 = string.Format("My name is {0} and I am {1} years old.", name, age);
			Console.WriteLine(message2);
		}
	}
}
