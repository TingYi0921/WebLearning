﻿namespace ConsoleApp35
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Person ian = new Person();
			ian.Name = "Ian Chu";
			ian.Age = 25;

			Console.WriteLine(ian.Introduce());
		}
	}

	class Person
	{
		public string Name;
		public int Age;

		public string Introduce()
		{
			return $"Hi, my name is {Name} and I am {Age} years old.";
		}
	}
}
