﻿namespace ConsoleApp32
{
	internal class Program
	{
		static void Main(string[] args)
		{
			int begin = 25, end = 10;

			if(begin > end)
			{
				int temp = begin; // temp = 25, begin = 25, end = 10;
				begin = end; // temp = 25, begin = 10, end = 10;
				end = temp; // temp = 25, begin = 10, end = 25
			}

			Console.WriteLine($"{begin} ~ {end}");
		}
	}
}
