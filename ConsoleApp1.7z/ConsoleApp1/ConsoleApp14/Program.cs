﻿namespace ConsoleApp14
{
	internal class Program
	{
		static void Main(string[] args)
		{
			int age = 5;
			string info = "";

			if (age > 18)
			{
				info = "已成年";
			}
			else
			{
				info = "未成年";
			}
			Console.WriteLine(info); // 此條件判斷式等於下方的三元運算子

			info = (age > 18) ? "已成年" : "未成年"; // 使用三元運算子簡化上面的條件判斷
			Console.WriteLine(info);

			string massage2 = (age > 18)
							? "已成年"
							: "未成年"; // 使用三元運算子簡化上面的條件判斷
			Console.WriteLine(massage2);
		}
	}
}
