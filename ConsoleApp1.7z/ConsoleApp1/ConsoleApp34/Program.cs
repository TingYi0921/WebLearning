﻿namespace ConsoleApp34
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Student ian = new Student("Ian", "ian@gmail.com");
			Console.WriteLine(ian.GetInfo());
		}
	}

	class Student
	{
		public string Name;
		public string Email;

		public Student(string name, string email)
		{
			Name = name;
			Email = email;
		}

		public string GetInfo()
		{
			return $"{Name}的Email: {Email}";
		}
	}
}
