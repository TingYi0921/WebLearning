﻿namespace ConsoleApp5
{
	// class是類別
	internal class Program
	{
		// 類別裡面，可以寫function(函數)，稱為method(方法)
		static void Main(string[] args)
		{
			// 函數裡面，可以宣告變數
			int height = 100;
			int weight = 60;

			string name = "小明";

			string message = "";
			message = name + height; // 小明100

			message =  name + height + weight; // 不好的寫法，小明10060 or 小明160

			message = name + (height + weight).ToString(); // 小明10060 or 小明160

			message = name + height.ToString() + weight.ToString(); // 小明10060 or 小明160

			Console.WriteLine(message);
		}
	}
}

// class, method命名，一律用大寫開頭
// 變數，一律用小寫開頭
// 常數，一律用大寫開頭(或全部都大寫)