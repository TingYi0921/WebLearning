﻿namespace ConsoleApp15
{
	internal class Program
	{
		static void Main(string[] args)
		{
			int hour = 4; // 停車時數
			int fee = 0; // 停車費用

			const int maxfee = 200; // 定義常數 maxfee，表示最大費用
			const int hourlyRate = 30; // 定義常數 hourlyRate，表示每小時費用

			fee = (hours * hourlyRate > maxfee) ? maxfee : (hours * hourlyRate); // 使用三元運算子計算費用

			Console.WriteLine($"停車費用: {fee}");
		}
	}
}
