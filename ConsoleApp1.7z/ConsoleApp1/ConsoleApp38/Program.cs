﻿namespace ConsoleApp38
{
	internal class Program
	{
		static void Main(string[] args)
		{
			string value = "0123456789";

			string result = value.Substring(3, 4);
			Console.WriteLine(result);
		}
	}
}
