﻿namespace hw5
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Console.Write("請輸入第一個字串: ");
			string input1 = Console.ReadLine().ToUpper();
			Console.Write("請輸入第二個字串: ");
			string input2 = Console.ReadLine().ToUpper();

			string[] input1Array = input1.Split(' ');
			string[] input2Array = input2.Split(' ');

			for (int i = 0; i < input1Array.Length; i++)
			{
				for (int j = 0; j < input2Array.Length; j++)
				{
					if (input1Array[i] == input2Array[j])
					{
						Console.WriteLine("輸入的字串內容相同");
					}
					else
					{
						Console.WriteLine("輸入的字串內容不同");
					}
				}
			}
		}
	}
}
