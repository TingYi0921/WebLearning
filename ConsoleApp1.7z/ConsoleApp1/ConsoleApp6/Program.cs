﻿namespace ConsoleApp6
{
	internal class Program
	{
		static void Main(string[] args)
		{
			string message = "ab\"c"; // 要在字串裡面加"時，前面需要加一個反斜線
			message = @"ab""c"; // 在字串前面加個@時，雙引號需要打兩次
			Console.WriteLine(message);

			string fullPath = "C:\\temp\\a.jpg"; // 字串為路徑時，反斜線需要打兩次
			fullPath = @"C:\temp\a.jpg"; // 在字串前面加@時，字串中的路徑只需要一個反斜線即可
			Console.WriteLine(fullPath);
		}
	}
}
