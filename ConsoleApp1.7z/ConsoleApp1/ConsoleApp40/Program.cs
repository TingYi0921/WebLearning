﻿namespace ConsoleApp40
{
	internal class Program
	{
		static void Main(string[] args)
		{
			var allen = new Student
			{
				Name = "Allen",
				Address = "123 Main St",
				Height = 180,
				Email = "allen@gmail.com"
			};
			allen.DateOfBirth = new DateTime(2000, 1, 1);

			Console.WriteLine(allen.Age);
		}
	}

	class Student
	{
		public string Name; // Field, not a property
		public string Address { get; set; } // Property with a getter and setter

		public int Height { get; set; }

		private string _email; // Backing field for the Email property

		public string Email // Property with validation in the setter
		{
			get { return _email; }
			set
			{
				if (value.Contains("@"))
				{
					_email = value;
				}
				else
				{
					throw new ArgumentException("Email must contain '@'");
				}
			}
		}

		private DateTime _dateOfBirth;

		public DateTime DateOfBirth
		{
			get 
			{ 
				return _dateOfBirth;
			} 
			set 
			{ 
				_dateOfBirth = value;
			}
		}
		public int Age
		{
			get
			{
				return DateTime.Now.Year - DateOfBirth.Year;
			}
		}

	}
}
