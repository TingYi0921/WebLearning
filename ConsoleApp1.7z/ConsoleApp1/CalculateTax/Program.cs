﻿namespace CalculateTax
{
	internal class Program
	{
		static void Main(string[] args)
		{
			int price = 100; // 假設價格為100元
			int tax = CalculateTax(price); // 計算稅額
			Console.WriteLine($"價格為:{price}"); // 輸出價格
			Console.WriteLine($"稅額為:{tax}"); // 輸出稅額
			Console.WriteLine($"總價為:{price + tax}"); // 輸出總價
		}

		static int CalculateTax(int price) 
		{
			price = price < 0 ? 0 : price; // 確保價格不為負數

			return (int)Math.Round(price * 0.05m, MidpointRounding.AwayFromZero); // 返回計算後的稅額
		}
	}
}
