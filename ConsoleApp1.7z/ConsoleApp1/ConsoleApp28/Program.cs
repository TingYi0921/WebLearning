﻿namespace ConsoleApp28
{
	internal class Program
	{
		static void Main(string[] args)
		{
			double n6 = 5.2;
			n6 = 5.3D;
			n6 = 5.4d;

			float n7 = 5.5F;
			n7 = 5.6f; // Corrected to use 'f' for float literal

			decimal n8 = 5.7M; // Corrected to use 'M' for decimal literal
			n8 = 5.8m; // Corrected to use 'm' for decimal literal

			int num1 = 10; int num2 = 4;

			double n1 = num1 / num2;
			double n2 = (double)num1 / num2; // Cast num1 to double before division
			double n3 = (double)(num1 / num2); // Cast the result of the division to double
			double n4 = (double)num1 / (double)num2; // Cast both num1 and num2 to double before division
			double n5 = (double)(num1 / (double)num2); // Cast num2 to double before division, then cast the result to double
			Console.WriteLine(n1);
			Console.WriteLine(n2);
			Console.WriteLine(n3);
			Console.WriteLine(n4);
			Console.WriteLine(n5);
		}
	}
}
