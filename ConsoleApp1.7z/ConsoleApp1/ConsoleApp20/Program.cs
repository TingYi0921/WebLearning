﻿namespace ConsoleApp20
{
	internal class Program
	{
		static void Main(string[] args)
		{
			List<int> number = new List<int> {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
			for(int i = 0; i < number.Count; i++)
			{
				{
					Console.WriteLine(number[i]);
				}
			}

			Console.WriteLine("-------------");

			for (int i = 0; i < number.Count; i++)
			{
				if (number[i] % 2 == 0)
				{
					Console.WriteLine(number[i]);
				}
			}

			Console.WriteLine("-------------");

			for (int i = number.Count-1; i >= 0; i--)
			{
				Console.WriteLine(number[i]);
			}
		}
	}
}
