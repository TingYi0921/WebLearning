﻿namespace ConsoleApp9
{
	internal class Program
	{
		static void Main(string[] args)
		{
			bool isMale = true;
			bool isFemale = true;

			if (isMale == true)
			{
				Console.WriteLine("Hi, 先生您好");
			}
			if (isFemale == true)
			{
				Console.WriteLine("Hi, 女士您好");
			}
		}
	}
}
