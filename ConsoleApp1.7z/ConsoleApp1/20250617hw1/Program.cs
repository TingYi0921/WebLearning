﻿namespace _20250617hw1
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Student name = new Student("Ian", 95);
			Console.WriteLine(name.DisplayInfo());
		}
	}

	class Student
	{
		public string Name;
		public int Score;

		public Student(string name, int score)
		{
			Name = name;
			Score = score;
		}

		public static string IsPass(Student student)
		{
			if (student.Score >= 60)
			{
				return "恭喜及格!"; // Pass
			}
			else
			{
				return "不及格!"; // Fail
			}

		}

		public string DisplayInfo()
		{
			return $"姓名: {Name}, 分數: {Score}, 結果: {IsPass(this)}";
		}
	}
}
