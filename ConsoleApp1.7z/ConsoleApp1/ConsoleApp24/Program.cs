﻿namespace ConsoleApp24
{
	internal class Program
	{
		static void Main(string[] args)
		{
			int num = 9;
			int result;
			for (int i = 1; i <= num; i++)
			{
				for (int j = 1; j <= num; j++)
				{
					//i, j從1開始，num從1開始，所以不用減1
					result = i * j;
					Console.Write($"{i} * {j} = {result}	");
				}
				Console.WriteLine(); // 換行
			}
		}
	}
}
