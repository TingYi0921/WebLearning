﻿using System.Text;

namespace ConsoleApp22
{
	internal class Program
	{
		static void Main(string[] args)
		{
			string item = "0123456789";
			string total = string.Empty;

			StringBuilder sb = new StringBuilder();

			for (int i = 0; i < 100000; i++)
			{
				sb.Append(item);
			}
			total = sb.ToString();

			Console.WriteLine(total.Length);
		}
	}
}
