﻿namespace ConsoleApp23
{
	internal class Program
	{
		static void Main(string[] args)
		{
			int sum = Add(8, 9);

			sum = CalculateSum(1, 100);

			Console.WriteLine(sum);
		}
		/// <summary>
		/// 傳回begin到end的總和
		/// </summary>
		/// <param name="begin"></param>
		/// <param name="end"></param>
		/// <returns>數列的總和</returns>
		static int CalculateSum(int begin, int end)
		{
			return (begin + end) * (end - begin + 1) / 2;
		}

		static int Add(int a, int b)
		{
			return a + b;
		}
	}
}
