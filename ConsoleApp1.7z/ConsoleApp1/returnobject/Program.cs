﻿namespace returnobject
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Result result = 總和超過指定值(250);
			Console.WriteLine($"Count: {result.Count}"); // 輸出 Count
			Console.WriteLine($"Sum: {result.Sum}"); // 輸出 Sum
		}
		static Result 總和超過指定值(int max)
		{
			var obj = new Result();
			obj.Count = 15;
			obj.Sum = 300;

			return obj;
		}
	}
	class Result
	{
		public int Count;
		public int Sum;
	}
}
