﻿namespace ConsoleApp4
{
	internal class Program
	{
		static void Main(string[] args)
		{
			//顯示一行文字
			Console.WriteLine("Hello, World!");
			//分兩次顯示文字，但是，是在同一行
			Console.Write("Hi,");
			Console.Write("Ian");

			//字串相加
			Console.WriteLine(); //因為上方沒有換行，所以這裡要換行
			Console.WriteLine("Hi, " + "Ian ,你今年" + 27 + "歲");

			//換行
			Console.WriteLine("第1行第2行"); //換行
			Console.WriteLine("第1行\n第2行"); //換行
			Console.WriteLine("第1行\r\n第2行"); //換行

			//return的效果
			Console.WriteLine("1234\rZ");


			//多行，使用@符號
			string message = @"第10行




第11行";

			Console.WriteLine(message);

			message = "Line1\n\n\n\n\nLine2";
			Console.WriteLine(message);
		}
	}
}
