﻿namespace ConsoleApp37
{
	internal class Program
	{
		static void Main(string[] args)
		{
			string str = "1000";

			//int number = Convert.ToInt32(str);
			//int number2 = int.Parse(str);
			int number3 = int.TryParse(str, out int result) ? result : 0;
			Console.WriteLine(number3);

			bool isNumber = int.TryParse(str, out int result1);
			if(isNumber)
			{
				Console.WriteLine($"成功轉換為整數: {result1}");
			}
			else
			{
				Console.WriteLine("轉換失敗，請確保字串是有效的整數格式。");
			}
		}
	}
}
