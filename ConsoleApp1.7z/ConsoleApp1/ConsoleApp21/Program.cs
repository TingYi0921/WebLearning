﻿namespace ConsoleApp21
{
	internal class Program
	{
		static void Main(string[] args)
		{
			int rows1 = 5;
			for (int i = 1; i <= rows1; i++) // 倒三角形 for (i = rows; i >= 1; i--)
			{
				string row1 = new string('*', i); // 講義p.86 Q1 & Q2
				Console.WriteLine(row1);
				//string row = new string(' ', rows - i) + new string('*', i); //講義p.86 Q3 & Q4，與Padleft結果相同
				//Console.WriteLine(row);
			}
			Console.WriteLine("-------------");

			int rows2 = 5;
			for (int i = 1; i <= rows2; i++)
			{
				string row2 = new string('*', i).PadLeft(rows2, ' ');
				Console.WriteLine(row2);
			}
			Console.WriteLine("-------------");

			int rows3 = 5;
			for (int i = 1; i <= rows3; i++)
			{
				string row3 = new string(' ', rows3 - i) + new string('*', 2 * i - 1);
				Console.WriteLine(row3);
			}
			Console.WriteLine("-------------");

			int rows4 = 5;
			for (int i = rows4; i >= 1; i--)
			{
				string row4 = new string('*', i);
				Console.WriteLine(row4);
			}
			Console.WriteLine("-------------");

			int rows5 = 5;
			for (int i = rows5; i >= 1; i--)
			{
				string row5 = new string('*', i).PadLeft(rows5, ' ');
				Console.WriteLine(row5);
			}
			Console.WriteLine("-------------");

			int rows6 = 5;
			for (int i = rows6; i >= 1; i--)
			{
				string row6 = new string(' ', rows6 - i) + new string('*', 2 * i - 1);
				Console.WriteLine(row6);
			}
		}
	}
}
